package com.example.budgetappfinal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddCardActivity extends AppCompatActivity {

    // Declare the EditText fields and the Button
    private EditText cardNameEditText;
    private EditText cardNumberEditText;
    private EditText expirationDateEditText;
    private EditText cvvEditText;
    private Button saveCardButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_card);  // Make sure this matches your layout file

        // Initialize the EditText fields and Button
        cardNameEditText = findViewById(R.id.card_name);
        cardNumberEditText = findViewById(R.id.card_number);
        expirationDateEditText = findViewById(R.id.expiration_date);
        cvvEditText = findViewById(R.id.cvv);
        saveCardButton = findViewById(R.id.save_card_button);

        // Set up the click listener for the save button
        saveCardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCardDetails();
            }
        });
    }

    // Method to save the card details
    private void saveCardDetails() {
        // Get the entered data
        String cardName = cardNameEditText.getText().toString().trim();
        String cardNumber = cardNumberEditText.getText().toString().trim();
        String expirationDate = expirationDateEditText.getText().toString().trim();
        String cvv = cvvEditText.getText().toString().trim();

        // Basic validation (You can add more checks)
        if (cardName.isEmpty() || cardNumber.isEmpty() || expirationDate.isEmpty() || cvv.isEmpty()) {
            Toast.makeText(AddCardActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else {
            // Save the card details (you can add logic to save to a database or shared preferences)
            Toast.makeText(AddCardActivity.this, "Card saved successfully!", Toast.LENGTH_SHORT).show();

            // Optionally, close the activity and return to the previous one
            finish();  // This will close the current activity and return to the previous one (MainActivity)
        }
    }
}
