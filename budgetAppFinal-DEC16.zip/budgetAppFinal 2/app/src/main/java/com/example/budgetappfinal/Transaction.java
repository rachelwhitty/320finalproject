package com.example.budgetappfinal;

public class Transaction {

    private String storeName;
    private String category;
    private double amount;
    private String cardName;

    // Constructor
    public Transaction(String storeName, String category, double amount, String cardName) {
        this.storeName = storeName;
        this.category = category;
        this.amount = amount;
        this.cardName = cardName;
    }

    // Getter and Setter for storeName
    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    // Getter and Setter for category
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    // Getter and Setter for amount
    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    // Getter and Setter for cardName
    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }
}
