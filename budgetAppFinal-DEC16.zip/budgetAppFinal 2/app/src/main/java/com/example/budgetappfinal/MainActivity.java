package com.example.budgetappfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // BottomNavigationView setup
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);
        bottomNav.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                // Change the fragment depending on which item is selected in the bottom nav
                if (item.getItemId() == R.id.nav_home) {
                    selectedFragment = new TransactionFragment();  // Open TransactionFragment on home button click
                } else if (item.getItemId() == R.id.nav_budget) {
                    selectedFragment = new BudgetFragment();
                } else if (item.getItemId() == R.id.nav_analytics) {
                    selectedFragment = new AnalyticsFragment();
                }

                // If a valid fragment was selected, replace the current fragment
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragmentContainer, selectedFragment)
                            .commit();
                }
                return true;
            }
        });

        // Load the TransactionFragment first when the app starts
        if (savedInstanceState == null) {
            // TransactionFragment is shown by default on launch
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, new TransactionFragment())  // Load TransactionFragment initially
                    .commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if present
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection using if statements
        if (item.getItemId() == R.id.nav_add_card) {
            // Launch AddNewCardActivity when "Add New Card" is clicked
            Intent intent = new Intent(MainActivity.this, AddCardActivity.class);
            startActivity(intent);
            return true;
        }

        // Return super for any other cases
        return super.onOptionsItemSelected(item);
    }

}
