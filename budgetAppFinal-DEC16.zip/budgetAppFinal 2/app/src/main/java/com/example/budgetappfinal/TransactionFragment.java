package com.example.budgetappfinal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class TransactionFragment extends Fragment {

    private RecyclerView transactionRecyclerView;
    private ArrayList<Transaction> allTransactions;
    private TransactionAdapter transactionAdapter;
    private ArrayList<Transaction> filteredTransactions;
    private Spinner cardSpinner;
    private TextView tabAll, tabGeneralBills, tabEntertainment, tabTravel, tabFood, tabClothes, tabOther;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_transactions, container, false);

        // Initialize RecyclerView
        transactionRecyclerView = view.findViewById(R.id.transactionRecyclerView);
        transactionRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Initialize transaction data
        allTransactions = new ArrayList<>();
        filteredTransactions = new ArrayList<>();

        // Sample transaction data
        allTransactions.add(new Transaction("Target", "General Bills", 100.00, "Card A"));
        allTransactions.add(new Transaction("Walmart", "General Bills", 50.00, "Card B"));
        allTransactions.add(new Transaction("Taco Bell", "Food", 20.00, "Card A"));
        allTransactions.add(new Transaction("Starbucks", "Food", 30.00, "Card C"));
        allTransactions.add(new Transaction("Netflix", "Entertainment", 15.00, "Card B"));
        allTransactions.add(new Transaction("Travelodge", "Travel", 200.00, "Card C"));

        // Set the adapter to the RecyclerView
        transactionAdapter = new TransactionAdapter(filteredTransactions);
        transactionRecyclerView.setAdapter(transactionAdapter);

        // Set up the Spinner for selecting cards
        cardSpinner = view.findViewById(R.id.spinner_card_select);

        // Sample data for Spinner (card names)
        ArrayList<String> cardOptions = new ArrayList<>();
        cardOptions.add("All");
        cardOptions.add("Card A");
        cardOptions.add("Card B");
        cardOptions.add("Card C");

        // Set the Adapter for the Spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, cardOptions);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cardSpinner.setAdapter(spinnerAdapter);

        // Set a listener for Spinner selection changes
        cardSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Get the selected card
                String selectedCard = (String) parentView.getItemAtPosition(position);
                showTransactionsByCard(selectedCard);  // Filter by the selected card
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing
            }
        });

        // Set up the category tabs
        tabAll = view.findViewById(R.id.tab_all);
        tabGeneralBills = view.findViewById(R.id.tab_general_bills);
        tabEntertainment = view.findViewById(R.id.tab_entertainment);
        tabTravel = view.findViewById(R.id.tab_travel);
        tabFood = view.findViewById(R.id.tab_food);
        tabClothes = view.findViewById(R.id.tab_clothes);
        tabOther = view.findViewById(R.id.tab_other);

        // Set click listeners for category tabs
        tabAll.setOnClickListener(v -> filterTransactions("All"));
        tabGeneralBills.setOnClickListener(v -> filterTransactions("General Bills"));
        tabEntertainment.setOnClickListener(v -> filterTransactions("Entertainment"));
        tabTravel.setOnClickListener(v -> filterTransactions("Travel"));
        tabFood.setOnClickListener(v -> filterTransactions("Food"));
        tabClothes.setOnClickListener(v -> filterTransactions("Clothes"));
        tabOther.setOnClickListener(v -> filterTransactions("Other"));

        // Initially show all transactions
        showTransactionsByCard("All");

        return view;
    }

    // Method to filter transactions by card
    private void showTransactionsByCard(String selectedCard) {
        filteredTransactions.clear();  // Clear previous filtered transactions

        if (selectedCard.equals("All")) {
            filteredTransactions.addAll(allTransactions);  // Show all transactions
        } else {
            // Filter transactions based on the selected card
            for (Transaction transaction : allTransactions) {
                if (transaction.getCardName().equals(selectedCard)) {
                    filteredTransactions.add(transaction);
                }
            }
        }

        // Notify the adapter that the data has changed
        transactionAdapter.notifyDataSetChanged();
    }

    // Method to filter transactions by category
    private void filterTransactions(String category) {
        filteredTransactions.clear();  // Clear previous filtered transactions

        for (Transaction transaction : allTransactions) {
            if (category.equals("All") || transaction.getCategory().equals(category)) {
                filteredTransactions.add(transaction);
            }
        }

        // Notify the adapter that the data has changed
        transactionAdapter.notifyDataSetChanged();
    }

    // Sample Adapter for RecyclerView
    public static class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

        private ArrayList<Transaction> transactions;

        public TransactionAdapter(ArrayList<Transaction> transactions) {
            this.transactions = transactions;
        }

        @Override
        public TransactionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // Inflate item layout for transaction (replace with actual item layout)
            View itemView = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
            return new TransactionViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(TransactionViewHolder holder, int position) {
            Transaction transaction = transactions.get(position);
            holder.bind(transaction);
        }

        @Override
        public int getItemCount() {
            return transactions.size();
        }

        // ViewHolder class for transaction item
        public static class TransactionViewHolder extends RecyclerView.ViewHolder {
            TextView text1, text2;

            public TransactionViewHolder(View itemView) {
                super(itemView);
                text1 = itemView.findViewById(android.R.id.text1);
                text2 = itemView.findViewById(android.R.id.text2);
            }

            public void bind(Transaction transaction) {
                text1.setText(transaction.getStoreName());  // Display store name
                text2.setText("$" + transaction.getAmount());  // Display transaction amount
            }
        }
    }

    // Sample Transaction class
    public static class Transaction {
        private String storeName;
        private String category;
        private double amount;
        private String cardName;

        public Transaction(String storeName, String category, double amount, String cardName) {
            this.storeName = storeName;
            this.category = category;
            this.amount = amount;
            this.cardName = cardName;
        }

        public String getStoreName() {
            return storeName;
        }

        public String getCategory() {
            return category;
        }

        public double getAmount() {
            return amount;
        }

        public String getCardName() {
            return cardName;
        }
    }
}
