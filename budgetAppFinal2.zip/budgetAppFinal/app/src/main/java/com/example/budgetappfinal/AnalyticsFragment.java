package com.example.budgetappfinal;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnalyticsFragment extends Fragment {

    private PieChartView transactionPieChart;
    private PieChartView budgetPieChart;
    private LinearLayout transactionKeyContainer;
    private LinearLayout budgetKeyContainer;
    private TextView totalSpentText;

    private final int[] COLORS = {
            Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.GRAY
    };

    private List<Transaction> transactions;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_analytics, container, false);

        // Initialize views
        transactionPieChart = view.findViewById(R.id.transactionPieChart);
        budgetPieChart = view.findViewById(R.id.budgetPieChart);
        transactionKeyContainer = view.findViewById(R.id.transactionKey);
        budgetKeyContainer = view.findViewById(R.id.budgetKey);
        totalSpentText = view.findViewById(R.id.totalSpent);

        // Simulate transaction data
        transactions = initializeFakeTransactions();

        // Fetch budgets
        Map<String, Float> budgetData = getBudgetData();

        // Set total spending
        float totalSpent = calculateTotalSpending(transactions);
        totalSpentText.setText("Total Spent: $" + totalSpent);

        // Display transaction chart
        populatePieChart(transactionPieChart, transactionKeyContainer, calculateTransactionData());

        // Display budget chart
        displayBudgetChart(budgetData);

        return view;
    }

    private List<Transaction> initializeFakeTransactions() {
        return List.of(
                new Transaction("Rent", 1200f, "General Bills"),
                new Transaction("Netflix", 15f, "Entertainment"),
                new Transaction("Flight Ticket", 500f, "Travel"),
                new Transaction("Dinner", 40f, "Food"),
                new Transaction("Shoes", 90f, "Clothes"),
                new Transaction("Electricity Bill", 100f, "General Bills"),
                new Transaction("Concert", 50f, "Entertainment"),
                new Transaction("Grocery", 75f, "Food")
        );
    }

    private Map<String, Float> getBudgetData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetPrefs", getActivity().MODE_PRIVATE);
        Map<String, Float> budgetData = new HashMap<>();

        int categoryCount = sharedPreferences.getInt("category_count", 0);
        for (int i = 0; i < categoryCount; i++) {
            String name = sharedPreferences.getString("category_" + i + "_name", "");
            float percentage = 0f;
            try {
                percentage = Float.parseFloat(sharedPreferences.getString("category_" + i + "_value", "0"));
            } catch (NumberFormatException ignored) {
            }
            budgetData.put(name, percentage);
        }
        return budgetData;
    }

    private float calculateTotalSpending(List<Transaction> transactions) {
        float total = 0;
        for (Transaction transaction : transactions) {
            total += transaction.amount;
        }
        return total;
    }

    private Map<String, Float> calculateTransactionData() {
        Map<String, Float> categoryTotals = new HashMap<>();
        for (Transaction transaction : transactions) {
            float currentTotal = categoryTotals.containsKey(transaction.category)
                    ? categoryTotals.get(transaction.category)
                    : 0f;
            categoryTotals.put(transaction.category, currentTotal + transaction.amount);
        }
        return normalizeData(categoryTotals);
    }

    private Map<String, Float> normalizeData(Map<String, Float> data) {
        float total = calculateTotalSpending(transactions);
        Map<String, Float> normalizedData = new HashMap<>();
        for (Map.Entry<String, Float> entry : data.entrySet()) {
            normalizedData.put(entry.getKey(), (entry.getValue() / total) * 100);
        }
        return normalizedData;
    }

    private void displayBudgetChart(Map<String, Float> budgetData) {
        if (budgetData.isEmpty()) {
            showNoBudgetsSet();
            return;
        }

        float budgetTotal = calculateTotalSpending(budgetData);
        if (budgetTotal < 100) {
            showIncompleteBudgets(budgetData, 100 - budgetTotal);
        } else {
            populatePieChart(budgetPieChart, budgetKeyContainer, budgetData);
        }
    }

    private float calculateTotalSpending(Map<String, Float> data) {
        float total = 0;
        for (float value : data.values()) {
            total += value;
        }
        return total;
    }

    private void showNoBudgetsSet() {
        Map<String, Float> data = new HashMap<>();
        data.put("No Budgets Set", 100f);
        budgetPieChart.setData(data);

        budgetKeyContainer.removeAllViews();
        TextView emptyText = new TextView(getContext());
        emptyText.setText("No Budgets Set");
        emptyText.setTextSize(16f);
        emptyText.setTextColor(Color.LTGRAY);
        budgetKeyContainer.addView(emptyText);
    }

    private void showIncompleteBudgets(Map<String, Float> budgetData, float remainingPercentage) {
        Map<String, Float> adjustedData = new HashMap<>(budgetData);
        adjustedData.put("Remaining", remainingPercentage);

        budgetPieChart.setData(adjustedData);
        populatePieChartKey(budgetKeyContainer, adjustedData);
    }

    private void populatePieChart(PieChartView pieChart, LinearLayout keyContainer, Map<String, Float> data) {
        pieChart.setData(data);
        populatePieChartKey(keyContainer, data);
    }

    private void populatePieChartKey(LinearLayout keyContainer, Map<String, Float> data) {
        keyContainer.removeAllViews();
        int colorIndex = 0;

        for (Map.Entry<String, Float> entry : data.entrySet()) {
            LinearLayout keyItem = new LinearLayout(getContext());
            keyItem.setOrientation(LinearLayout.HORIZONTAL);

            View colorIndicator = new View(getContext());
            colorIndicator.setLayoutParams(new LinearLayout.LayoutParams(50, 50));
            colorIndicator.setBackgroundColor(COLORS[colorIndex % COLORS.length]);

            TextView keyText = new TextView(getContext());
            keyText.setText(entry.getKey() + ": " + entry.getValue() + "%");
            keyText.setTextSize(14f);
            keyText.setPadding(16, 0, 0, 0);

            keyItem.addView(colorIndicator);
            keyItem.addView(keyText);

            keyContainer.addView(keyItem);
            colorIndex++;
        }
    }

    private static class Transaction {
        String name;
        float amount;
        String category;

        Transaction(String name, float amount, String category) {
            this.name = name;
            this.amount = amount;
            this.category = category;
        }
    }
}
