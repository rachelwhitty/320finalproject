package com.example.budgetappfinal;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class TransactionsFragment extends Fragment {

    private List<Transaction> transactions;
    private List<Transaction> filteredTransactions;
    private LinearLayout transactionList;
    private TextView selectedTab;
    private TextView totalAmount;
    private EditText searchBar;
    private Spinner cardSpinner;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transactions, container, false);

        transactionList = view.findViewById(R.id.transactionList);
        totalAmount = view.findViewById(R.id.totalAmount);
        searchBar = view.findViewById(R.id.search_bar);
        cardSpinner = view.findViewById(R.id.cardSpinner);

        initializeFakeTransactions();
        setUpCardSpinner();
        setUpCategoryFilters(view);
        setUpSearchBar();

        // Default: Show all transactions
        selectedTab = view.findViewById(R.id.tab_all);
        highlightSelectedTab(selectedTab);
        filteredTransactions = new ArrayList<>(transactions);
        displayTransactions(filteredTransactions);

        return view;
    }

    private void initializeFakeTransactions() {
        transactions = new ArrayList<>();
        transactions.add(new Transaction("Rent", "$1200", "General Bills", "Visa"));
        transactions.add(new Transaction("Netflix", "$15", "Entertainment", "Visa"));
        transactions.add(new Transaction("Flight Ticket", "$500", "Travel", "Amex"));
        transactions.add(new Transaction("Dinner", "$40", "Food", "Discover"));
        transactions.add(new Transaction("Shoes", "$90", "Clothes", "Mastercard"));
        transactions.add(new Transaction("Electricity Bill", "$100", "General Bills", "Discover"));
        transactions.add(new Transaction("Concert", "$50", "Entertainment", "Visa"));
        transactions.add(new Transaction("Grocery", "$75", "Food", "Mastercard"));
    }

    private void setUpCardSpinner() {
        List<String> cardOptions = new ArrayList<>();
        cardOptions.add("All Cards");
        cardOptions.add("Visa");
        cardOptions.add("Amex");
        cardOptions.add("Mastercard");
        cardOptions.add("Discover");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                getContext(),
                android.R.layout.simple_spinner_item,
                cardOptions
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cardSpinner.setAdapter(adapter);

        cardSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCard = cardOptions.get(position);
                filterTransactions(selectedCard, selectedTab.getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setUpCategoryFilters(View view) {
        View.OnClickListener filterClickListener = v -> {
            TextView clickedTab = (TextView) v;
            highlightSelectedTab(clickedTab);

            String category = clickedTab.getText().toString();
            filterTransactions(cardSpinner.getSelectedItem().toString(), category);
        };

        view.findViewById(R.id.tab_all).setOnClickListener(filterClickListener);
        view.findViewById(R.id.tab_general_bills).setOnClickListener(filterClickListener);
        view.findViewById(R.id.tab_entertainment).setOnClickListener(filterClickListener);
        view.findViewById(R.id.tab_travel).setOnClickListener(filterClickListener);
        view.findViewById(R.id.tab_food).setOnClickListener(filterClickListener);
        view.findViewById(R.id.tab_clothes).setOnClickListener(filterClickListener);
        view.findViewById(R.id.tab_other).setOnClickListener(filterClickListener);
    }

    private void filterTransactions(String card, String category) {
        filteredTransactions = new ArrayList<>();
        for (Transaction transaction : transactions) {
            boolean matchesCard = card.equals("All Cards") || transaction.getCard().equals(card);
            boolean matchesCategory = category.equals("All") || transaction.getCategory().equals(category);
            if (matchesCard && matchesCategory) {
                filteredTransactions.add(transaction);
            }
        }
        displayTransactions(filteredTransactions);
    }

    private void setUpSearchBar() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().toLowerCase();
                List<Transaction> searchedTransactions = new ArrayList<>();
                for (Transaction transaction : filteredTransactions) {
                    if (transaction.getName().toLowerCase().contains(query)) {
                        searchedTransactions.add(transaction);
                    }
                }
                displayTransactions(searchedTransactions);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void displayTransactions(List<Transaction> displayedTransactions) {
        transactionList.removeAllViews();
        double total = 0;

        for (Transaction transaction : displayedTransactions) {
            total += Double.parseDouble(transaction.getAmount().replace("$", ""));
            View transactionView = createTransactionView(transaction);
            transactionList.addView(transactionView);
        }

        totalAmount.setText(String.format("Total: $%.2f", total));
    }

    private View createTransactionView(Transaction transaction) {
        LinearLayout transactionLayout = new LinearLayout(getContext());
        transactionLayout.setOrientation(LinearLayout.HORIZONTAL);
        transactionLayout.setPadding(16, 16, 16, 16);
        transactionLayout.setBackgroundResource(R.drawable.transaction_background);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(0, 0, 0, 16);
        transactionLayout.setLayoutParams(layoutParams);

        TextView name = new TextView(getContext());
        name.setText(transaction.getName());
        name.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        transactionLayout.addView(name);

        TextView amount = new TextView(getContext());
        amount.setText(transaction.getAmount());
        transactionLayout.addView(amount);

        return transactionLayout;
    }

    private void highlightSelectedTab(TextView clickedTab) {
        if (selectedTab != null) {
            selectedTab.setBackgroundResource(R.drawable.category_background);
            selectedTab.setTextColor(getResources().getColor(android.R.color.white));
        }

        clickedTab.setBackgroundResource(R.drawable.category_background_selected);
        clickedTab.setTextColor(getResources().getColor(android.R.color.black));
        selectedTab = clickedTab;
    }

    private static class Transaction {
        private final String name;
        private final String amount;
        private final String category;
        private final String card;

        public Transaction(String name, String amount, String category, String card) {
            this.name = name;
            this.amount = amount;
            this.category = category;
            this.card = card;
        }

        public String getName() {
            return name;
        }

        public String getAmount() {
            return amount;
        }

        public String getCategory() {
            return category;
        }

        public String getCard() {
            return card;
        }
    }
}
