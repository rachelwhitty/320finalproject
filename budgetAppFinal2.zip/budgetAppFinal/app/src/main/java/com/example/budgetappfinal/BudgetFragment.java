package com.example.budgetappfinal;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class BudgetFragment extends Fragment {

    private List<LinearLayout> categoryInputs;
    private LinearLayout categoriesContainer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_budget, container, false);

        categoriesContainer = view.findViewById(R.id.categoryContainer);
        categoryInputs = new ArrayList<>();

        loadSavedCategories();

        Button saveButton = view.findViewById(R.id.saveButton);
        saveButton.setOnClickListener(v -> saveCategories());

        Button addCategoryButton = view.findViewById(R.id.addCategoryButton);
        addCategoryButton.setOnClickListener(v -> addCategoryInput("", ""));

        Button removeCategoryButton = view.findViewById(R.id.removeCategoryButton);
        removeCategoryButton.setOnClickListener(v -> removeLastCategoryInput());

        return view;
    }

    private void addCategoryInput(String categoryName, String percentage) {
        LinearLayout layout = new LinearLayout(getContext());
        layout.setOrientation(LinearLayout.HORIZONTAL);

        EditText categoryNameInput = new EditText(getContext());
        categoryNameInput.setHint("Category Name");
        categoryNameInput.setText(categoryName);
        categoryNameInput.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));

        EditText percentageInput = new EditText(getContext());
        percentageInput.setHint("Enter %");
        percentageInput.setText(percentage);
        percentageInput.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        percentageInput.setBackgroundResource(R.drawable.white_bubble);

        layout.addView(categoryNameInput);
        layout.addView(percentageInput);

        categoriesContainer.addView(layout);
        categoryInputs.add(layout);
    }

    private void removeLastCategoryInput() {
        if (!categoryInputs.isEmpty()) {
            LinearLayout lastCategory = categoryInputs.remove(categoryInputs.size() - 1);
            categoriesContainer.removeView(lastCategory);
        } else {
            Toast.makeText(getContext(), "No categories to remove.", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveCategories() {
        if (!validateInputs()) return;

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetPrefs", getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.clear(); // Clear previous categories
        editor.putInt("category_count", categoryInputs.size());

        for (int i = 0; i < categoryInputs.size(); i++) {
            LinearLayout layout = categoryInputs.get(i);
            EditText categoryInput = (EditText) layout.getChildAt(0);
            EditText percentageInput = (EditText) layout.getChildAt(1);

            editor.putString("category_" + i + "_name", categoryInput.getText().toString());
            editor.putString("category_" + i + "_value", percentageInput.getText().toString());
        }

        editor.apply();
        Toast.makeText(getContext(), "Categories saved successfully!", Toast.LENGTH_SHORT).show();
    }

    private boolean validateInputs() {
        for (LinearLayout layout : categoryInputs) {
            EditText categoryInput = (EditText) layout.getChildAt(0);
            EditText percentageInput = (EditText) layout.getChildAt(1);

            if (categoryInput.getText().toString().isEmpty() || percentageInput.getText().toString().isEmpty()) {
                new AlertDialog.Builder(getContext())
                        .setTitle("Incomplete Inputs")
                        .setMessage("Please fill in both the category name and percentage for all entries.")
                        .setPositiveButton("OK", null)
                        .show();
                return false;
            }
        }
        return true;
    }

    private void loadSavedCategories() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetPrefs", getActivity().MODE_PRIVATE);
        int categoryCount = sharedPreferences.getInt("category_count", 0);

        for (int i = 0; i < categoryCount; i++) {
            String categoryName = sharedPreferences.getString("category_" + i + "_name", "");
            String percentage = sharedPreferences.getString("category_" + i + "_value", "");
            addCategoryInput(categoryName, percentage);
        }
    }
}
